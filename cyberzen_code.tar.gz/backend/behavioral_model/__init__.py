"""Behavioral model module."""
