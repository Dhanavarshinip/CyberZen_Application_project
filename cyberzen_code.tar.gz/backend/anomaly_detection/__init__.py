"""Anomaly detection module."""
