"""Collectors module."""
