import sqlite3, os, gzip, shutil

gz_path = '/home/ubuntu/cyberzen/data_db.gz'
local_db = '/home/ubuntu/cyberzen/data/local_cyberthreat.db'
cloud_db = '/home/ubuntu/cyberzen/data/cyberthreat.db'

if os.path.exists(gz_path):
    print('[*] Decompressing incoming database...')
    with gzip.open(gz_path, 'rb') as f_in:
        with open(local_db, 'wb') as f_out:
            shutil.copyfileobj(f_in, f_out)
    os.remove(gz_path)
    print(f'[OK] Decompressed local_cyberthreat.db ({os.path.getsize(local_db)} bytes)')

if os.path.exists(local_db) and os.path.exists(cloud_db):
    print('[*] Merging local records into EC2 cloud database...')
    conn = sqlite3.connect(cloud_db)
    c = conn.cursor()
    c.execute(f"ATTACH DATABASE '{local_db}' AS local")

    tables = ['users', 'devices', 'events', 'behavior_profiles', 'risk_history', 'incidents', 'incident_events', 'system_settings', 'user_allowed_emails']
    for t in tables:
        try:
            c.execute(f"INSERT OR IGNORE INTO {t} SELECT * FROM local.{t}")
            print(f'  ✓ Merged {t}')
        except Exception as e:
            print(f'  ! Notice on {t}: {e}')

    conn.commit()
    conn.close()
    os.remove(local_db)
    print('[OK] SQLite database merge complete!')
