// DigitalGuard AI Mock Data Structure for Dashboard & Analytics

export const DASHBOARD_METRICS = {
  securityScore: 88,
  securityScoreStatus: "Optimal Protection",
  activeAnomalies: 3,
  criticalIncidents: 1,
  connectedDevices: 14,
  riskLevel: "Low-Medium Risk",
  lastScanned: "Just now"
};

export const AI_SECURITY_SUMMARY = {
  headline: "DigitalGuard AI Protection Active",
  status: "Normal Operations with 1 Mitigated Incident",
  summaryText: "DigitalGuard AI is actively monitoring 14 connected devices across 3 network segments. Behavioral baseline analysis detected an unauthorized MFA bypass request from a Tor Exit Node (IP 185.220.101.45) at 11:20 AM. The session was automatically invalidated and credential rotation is recommended. System overall health remains optimal at 88/100.",
  keyInsights: [
    "1 Anomalous login attempt blocked from Frankfurt (Tor subnet)",
    "Device Mac-Workstation-01 flagged for out-of-hours API traffic",
    "All core database gateway connections encrypted via TLS 1.3"
  ]
};

export const THREAT_TREND_DATA = [
  { time: "00:00", risk: 12, anomalies: 0 },
  { time: "04:00", risk: 10, anomalies: 0 },
  { time: "08:00", risk: 18, anomalies: 1 },
  { time: "11:20", risk: 78, anomalies: 3 },
  { time: "12:00", risk: 42, anomalies: 1 },
  { time: "14:00", risk: 24, anomalies: 0 }
];

export const REALTIME_ACTIVITIES = [
  {
    id: "act_101",
    timestamp: "14:18:02",
    activity: "SSO Authentication Success",
    device: "MacBook Pro M3 (Sarah)",
    source: "192.168.1.104 (San Francisco)",
    risk: "4%",
    riskLevel: "Low",
    status: "Verified"
  },
  {
    id: "act_102",
    timestamp: "14:15:30",
    activity: "Database API Query Batch",
    device: "Dell XPS Workstation",
    source: "192.168.1.108 (New York)",
    risk: "12%",
    riskLevel: "Low",
    status: "Verified"
  },
  {
    id: "act_103",
    timestamp: "13:50:12",
    activity: "High Volume Export Attempt",
    device: "ThinkPad Linux Workstation",
    source: "192.168.1.150 (Austin)",
    risk: "68%",
    riskLevel: "High",
    status: "Flagged"
  },
  {
    id: "act_104",
    timestamp: "11:20:15",
    activity: "Anomalous MFA Session Replay",
    device: "Unrecognized Device",
    source: "185.220.101.45 (Tor Exit Node)",
    risk: "94%",
    riskLevel: "Critical",
    status: "Blocked"
  },
  {
    id: "act_105",
    timestamp: "09:30:00",
    activity: "Vault Credentials Renewal",
    device: "MacBook Pro M3 (Sarah)",
    source: "192.168.1.104 (San Francisco)",
    risk: "8%",
    riskLevel: "Low",
    status: "Verified"
  }
];

export const RECENT_ALERTS = [
  {
    id: "alt_01",
    title: "Tor Exit Node Login Attempt",
    description: "Impossible travel anomaly detected from Frankfurt (185.220.101.45) 3 mins after US login",
    timestamp: "11:20 AM",
    severity: "critical",
    type: "Account Takeover"
  },
  {
    id: "alt_02",
    title: "Unusual Data Exfiltration Volume",
    description: "Database export rate exceeded baseline by 450% on ThinkPad Workstation",
    timestamp: "01:50 PM",
    severity: "high",
    type: "Data Protection"
  },
  {
    id: "alt_03",
    title: "Out-of-Hours Secret Access",
    description: "HashiCorp Vault read request dispatched outside configured employee working window",
    timestamp: "02:10 AM",
    severity: "medium",
    type: "Access Control"
  },
  {
    id: "alt_04",
    title: "New Unregistered Endpoint Joined",
    description: "iPhone 15 Pro initiated corporate WiFi connection without MDM profile",
    timestamp: "08:15 AM",
    severity: "low",
    type: "Device Monitoring"
  }
];

export const CONNECTED_DEVICES_LIST = [
  { id: "dev_1", name: "MacBook Pro M3", owner: "Sarah Connor", ip: "192.168.1.104", status: "Protected", os: "macOS Sonoma", type: "Laptop" },
  { id: "dev_2", name: "Dell XPS 15", owner: "Alex Mercer", ip: "192.168.1.108", status: "Protected", os: "Windows 11 Enterprise", type: "Desktop" },
  { id: "dev_3", name: "ThinkPad Linux", owner: "David Miller", ip: "192.168.1.150", status: "Attention Required", os: "Ubuntu 24.04 LTS", type: "Workstation" },
  { id: "dev_4", name: "iPhone 15 Pro", owner: "Elena Rostova", ip: "10.0.4.12", status: "Protected", os: "iOS 17.5", type: "Mobile" },
  { id: "dev_5", name: "Production K8s Gateway", owner: "Infrastructure", ip: "10.0.0.1", status: "Protected", os: "Linux Server", type: "Server" },
  { id: "dev_6", name: "Core Banking DB Server", owner: "Finance System", ip: "10.0.0.5", status: "Protected", os: "RHEL 9", type: "Server" }
];
