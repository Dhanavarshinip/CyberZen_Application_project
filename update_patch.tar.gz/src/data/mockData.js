// Baseline security entities and attack scenario payloads

export const INITIAL_ENTITIES = {
  users: [
    { id: "usr_1", name: "Sarah Connor", role: "DevOps Engineer", dept: "Infrastructure", baselineRisk: 12 },
    { id: "usr_2", name: "Alex Mercer", role: "Financial Analyst", dept: "Finance", baselineRisk: 8 },
    { id: "usr_3", name: "David Miller", role: "Database Administrator", dept: "IT Security", baselineRisk: 15 },
    { id: "usr_4", name: "Elena Rostova", role: "Executive Assistant", dept: "Executive", baselineRisk: 5 },
  ],
  devices: [
    { id: "dev_mac_01", owner: "usr_1", type: "MacBook Pro M3", ip: "192.168.1.104", mac: "00:1B:44:11:3A:B7", os: "macOS Sonoma" },
    { id: "dev_win_02", owner: "usr_2", type: "Dell XPS 15", ip: "192.168.1.108", mac: "54:EE:75:22:9C:F1", os: "Windows 11 Enterprise" },
    { id: "dev_lin_03", owner: "usr_3", type: "ThinkPad Workstation", ip: "192.168.1.150", mac: "A4:80:94:88:E2:12", os: "Ubuntu 24.04 LTS" },
    { id: "dev_iphone_04", owner: "usr_4", type: "iPhone 15 Pro", ip: "10.0.4.12", mac: "88:E9:FE:41:2B:90", os: "iOS 17.5" },
  ],
  sessions: [
    { id: "ses_881", user: "usr_1", device: "dev_mac_01", location: "San Francisco, US", ip: "192.168.1.104", startTime: "10:14:02" },
    { id: "ses_882", user: "usr_2", device: "dev_win_02", location: "New York, US", ip: "192.168.1.108", startTime: "09:30:15" },
    { id: "ses_883", user: "usr_3", device: "dev_lin_03", location: "Austin, US", ip: "192.168.1.150", startTime: "08:45:00" },
  ],
  applications: [
    { id: "app_k8s", name: "Kubernetes Cluster Gateway", port: 6443, tier: "Critical" },
    { id: "app_fin_db", name: "Core Banking & Transactions API", port: 5432, tier: "Critical" },
    { id: "app_slack", name: "Internal Slack Workspace", port: 443, tier: "Standard" },
    { id: "app_vault", name: "HashiCorp Vault Credentials", port: 8200, tier: "Critical" },
  ]
};

export const INITIAL_TELEMETRY_LOGS = [
  {
    id: "evt_001",
    timestamp: "11:15:02",
    type: "LOGIN",
    user: "usr_1",
    device: "dev_mac_01",
    ip: "192.168.1.104",
    location: "San Francisco, US",
    app: "app_k8s",
    status: "SUCCESS",
    anomalyScore: 0.04,
    details: "Standard SSO authentication via Okta MFA",
    severity: "low"
  },
  {
    id: "evt_002",
    timestamp: "11:16:30",
    type: "NETWORK_TRAFFIC",
    user: "usr_2",
    device: "dev_win_02",
    ip: "192.168.1.108",
    location: "New York, US",
    app: "app_fin_db",
    status: "SUCCESS",
    anomalyScore: 0.08,
    details: "Queried monthly ledger summary (1.2 KB payload)",
    severity: "low"
  },
  {
    id: "evt_003",
    timestamp: "11:17:12",
    type: "APPLICATION_API",
    user: "usr_3",
    device: "dev_lin_03",
    ip: "192.168.1.150",
    location: "Austin, US",
    app: "app_vault",
    status: "SUCCESS",
    anomalyScore: 0.12,
    details: "Renewed read token for database staging secrets",
    severity: "low"
  }
];

export const ATTACK_SCENARIOS = [
  {
    id: "scenario_ato_ransomware",
    title: "Credential Stuffing -> Lateral Movement -> Ransomware Ingress",
    category: "Account Takeover & Ransomware",
    description: "Attacker uses compromised credentials from an unknown IP to hijack Sarah's session, scans internal DBs, and attempts root escalation on Kubernetes Gateway.",
    difficulty: "High Severity",
    events: [
      {
        id: "atk_101",
        timestamp: "11:20:00",
        type: "LOGIN_FAILED",
        user: "usr_1",
        device: "dev_unregistered_99",
        ip: "185.220.101.45 (Tor Exit Node)",
        location: "Frankfurt, DE",
        app: "app_vault",
        status: "FAILED",
        anomalyScore: 0.78,
        details: "14 failed password attempts in 8 seconds (Credential Stuffing)",
        severity: "high"
      },
      {
        id: "atk_102",
        timestamp: "11:20:15",
        type: "LOGIN_SUCCESS",
        user: "usr_1",
        device: "dev_unregistered_99",
        ip: "185.220.101.45 (Tor Exit Node)",
        location: "Frankfurt, DE",
        app: "app_vault",
        status: "SUCCESS",
        anomalyScore: 0.94,
        details: "Impossible Travel anomaly! Login from Frankfurt 3 mins after SF session",
        severity: "critical"
      },
      {
        id: "atk_103",
        timestamp: "11:21:05",
        type: "CREDENTIAL_EXFIL",
        user: "usr_1",
        device: "dev_unregistered_99",
        ip: "185.220.101.45",
        location: "Frankfurt, DE",
        app: "app_vault",
        status: "WARNING",
        anomalyScore: 0.96,
        details: "Extracted cluster root admin tokens from HashiCorp Vault",
        severity: "critical"
      },
      {
        id: "atk_104",
        timestamp: "11:22:10",
        type: "LATERAL_MOVEMENT",
        user: "usr_1",
        device: "dev_mac_01",
        ip: "192.168.1.104",
        location: "San Francisco, US",
        app: "app_k8s",
        status: "CRITICAL",
        anomalyScore: 0.98,
        details: "Unauthorized execution of `kubectl exec -it prod-db-0 -- /bin/bash` with stolen token",
        severity: "critical"
      },
      {
        id: "atk_105",
        timestamp: "11:23:40",
        type: "RANSOMWARE_BEACON",
        user: "usr_1",
        device: "dev_mac_01",
        ip: "91.218.114.12 (C2 Server)",
        location: "Unknown",
        app: "app_k8s",
        status: "CRITICAL",
        anomalyScore: 0.99,
        details: "Encrypted payload dropper detected: `lockbit_v4_linux_amd64.sh`",
        severity: "critical"
      }
    ]
  },
  {
    id: "scenario_session_fraud",
    title: "Session Hijacking -> High-Volume Transaction Fraud",
    category: "Financial Fraud",
    description: "Attacker clones session token for Alex Mercer, bypasses device biometric check, and attempts unauthorized wire transfers.",
    difficulty: "Critical Severity",
    events: [
      {
        id: "atk_201",
        timestamp: "11:24:00",
        type: "SESSION_HIJACK",
        user: "usr_2",
        device: "dev_unknown_mac",
        ip: "45.142.120.9",
        location: "Bucharest, RO",
        app: "app_fin_db",
        status: "WARNING",
        anomalyScore: 0.88,
        details: "Session replay attack: Token `ses_882` reused from unrecognized User-Agent",
        severity: "high"
      },
      {
        id: "atk_202",
        timestamp: "11:24:45",
        type: "TRANSACTION_ANOMALY",
        user: "usr_2",
        device: "dev_unknown_mac",
        ip: "45.142.120.9",
        location: "Bucharest, RO",
        app: "app_fin_db",
        status: "CRITICAL",
        anomalyScore: 0.97,
        details: "Initiated 3x $250,000 offshore wire transfer to flagged account offshore",
        severity: "critical"
      }
    ]
  },
  {
    id: "scenario_db_scraping",
    title: "Off-Hours API Scraping & Data Exfiltration",
    category: "Data Exfiltration",
    description: "Automated bot script scraping customer PII database using DB administrator credentials.",
    difficulty: "Medium-High Severity",
    events: [
      {
        id: "atk_301",
        timestamp: "11:25:00",
        type: "HIGH_FREQ_API",
        user: "usr_3",
        device: "dev_lin_03",
        ip: "192.168.1.150",
        location: "Austin, US",
        app: "app_fin_db",
        status: "WARNING",
        anomalyScore: 0.82,
        details: "4,200 SELECT queries per minute detected (Normal baseline: 12/min)",
        severity: "high"
      },
      {
        id: "atk_302",
        timestamp: "11:25:50",
        type: "DATA_EXFIL",
        user: "usr_3",
        device: "dev_lin_03",
        ip: "103.253.145.18",
        location: "Singapore",
        app: "app_fin_db",
        status: "CRITICAL",
        anomalyScore: 0.95,
        details: "Outbound encrypted SSL tunnel stream payload: 4.8 GB exported to external IP",
        severity: "critical"
      }
    ]
  }
];
